from defines import *
import time
from copy import deepcopy

# Point (x, y) if in the valid position of the board.
def isValidPos(x,y):
    return x>0 and x<Defines.GRID_NUM-1 and y>0 and y<Defines.GRID_NUM-1
    
def init_board(board):
    for i in range(21):
        board[i][0] = board[0][i] = board[i][Defines.GRID_NUM - 1] = board[Defines.GRID_NUM - 1][i] = Defines.BORDER
    for i in range(1, Defines.GRID_NUM - 1):
        for j in range(1, Defines.GRID_NUM - 1):
            board[i][j] = Defines.NOSTONE
            
def make_move(board, move, color):
    board[move.positions[0].x][move.positions[0].y] = color
    board[move.positions[1].x][move.positions[1].y] = color

def unmake_move(board, move):
    board[move.positions[0].x][move.positions[0].y] = Defines.NOSTONE
    board[move.positions[1].x][move.positions[1].y] = Defines.NOSTONE

def is_win_by_premove(board, preMove):
    # Verificar si preMove es una instancia de StoneMove
    if isinstance(preMove, StoneMove):
        for position in preMove.positions:
            x, y = position.x, position.y
            directions = [(1, 0), (0, 1), (1, 1), (1, -1)]

            for direction in directions:
                count = 0
                movStone = board[x][y]

                if movStone in [Defines.BORDER, Defines.NOSTONE]:
                    continue

                dx, dy = direction
                nx, ny = x + dx, y + dy
                while 0 <= nx < len(board) and 0 <= ny < len(board[0]) and board[nx][ny] == movStone:
                    nx += dx
                    ny += dy
                    count += 1

                nx, ny = x - dx, y - dy
                while 0 <= nx < len(board) and 0 <= ny < len(board[0]) and board[nx][ny] == movStone:
                    nx -= dx
                    ny -= dy
                    count += 1

                if count >= 6:
                    return True
    return False

def get_msg(max_len):
    buf = input().strip()
    return buf[:max_len]

def log_to_file(msg):
    g_log_file_name = Defines.LOG_FILE
    try:
        with open(g_log_file_name, "a") as file:
            tm = time.time()
            ptr = time.ctime(tm)
            ptr = ptr[:-1]
            file.write(f"[{ptr}] - {msg}\n")
        return 0
    except Exception as e:
        print(f"Error: Can't open log file - {g_log_file_name}")
        return -1

def move2msg(move):
    if move.positions[0].x == move.positions[1].x and move.positions[0].y == move.positions[1].y:
        msg = f"{chr(ord('S') - move.positions[0].x + 1)}{chr(move.positions[0].y + ord('A') - 1)}"
        return msg
    else:
        msg = f"{chr(move.positions[0].y + ord('A') - 1)}{chr(ord('S') - move.positions[0].x + 1)}" \
              f"{chr(move.positions[1].y + ord('A') - 1)}{chr(ord('S') - move.positions[1].x + 1)}"
        return msg

def msg2move(msg):
    move = StoneMove()
    if len(msg) == 2:
        move.positions[0].x = move.positions[1].x = ord('S') - ord(msg[1]) + 1
        move.positions[0].y = move.positions[1].y = ord(msg[0]) - ord('A') + 1
        move.score = 0
        return move
    else:
        move.positions[0].x = ord('S') - ord(msg[1]) + 1
        move.positions[0].y = ord(msg[0]) - ord('A') + 1
        move.positions[1].x = ord('S') - ord(msg[3]) + 1
        move.positions[1].y = ord(msg[2]) - ord('A') + 1
        move.score = 0
        return move

def print_board(board, preMove=None):
    print("   " + "".join([chr(i + ord('A') - 1)+" " for i in range(1, Defines.GRID_NUM - 1)]))
    for i in range(1, Defines.GRID_NUM - 1):
        print(f"{chr(ord('A') - 1 + i)}", end=" ")
        for j in range(1, Defines.GRID_NUM - 1):
            x = Defines.GRID_NUM - 1 - j
            y = i
            stone = board[x][y]
            if stone == Defines.NOSTONE:
                print(" -", end="")
            elif stone == Defines.BLACK:
                print(" O", end="")
            elif stone == Defines.WHITE:
                print(" *", end="")
        print(" ", end="")        
        print(f"{chr(ord('A') - 1 + i)}", end="\n")
    print("   " + "".join([chr(i + ord('A') - 1)+" " for i in range(1, Defines.GRID_NUM - 1)]))

def print_score(move_list, n):
    board = [[0] * Defines.GRID_NUM for _ in range(Defines.GRID_NUM)]
    for move in move_list:
        board[move.x][move.y] = move.score

    print("  " + "".join([f"{i:4}" for i in range(1, Defines.GRID_NUM - 1)]))
    for i in range(1, Defines.GRID_NUM - 1):
        print(f"{i:2}", end="")
        for j in range(1, Defines.GRID_NUM - 1):
            score = board[i][j]
            if score == 0:
                print("   -", end="")
            else:
                print(f"{score:4}", end="")
        print()

# ------------------------- Funciones implementadas -------------------------

# Evaluar estado del tablero
SIX_IN_LINE = 100000
FIVE_IN_LINE = 10000
FOUR_IN_LINE = 1000
THREE_IN_LINE = 100
TWO_IN_LINE = 10
ONE_IN_LINE = 1

# Evaluar estado del tablero
def evaluate_board(board, player):
    score = 0
    
    # Evaluar filas
    for row in range(len(board)):
        for col in range(len(board[0]) - 6):
            window = board[row][col:col + 6]
            score = score + evaluate_window(window, player)
    
    # Evaluar columnas
    for col in range(len(board[0])):
        for row in range(len(board) - 6):
            window = [board[row + i][col] for i in range(6)]
            score = score + evaluate_window(window, player)
    
    # Evaluar diagonales hacia la derecha
    for row in range(len(board) - 6):
        for col in range(len(board[0]) - 6):
            window = [board[row + i][col + i] for i in range(6)]
            score = score + evaluate_window(window, player)
    
    # Evaluar diagonales hacia la izquierda
    for row in range(len(board) - 6):
        for col in range(5, len(board[0])):
            window = [board[row + i][col - i] for i in range(6)]
            score = score + evaluate_window(window, player)

    return score

def evaluate_window(window, player):
    if player == 2:
        opponent = player - 1
    else:
        opponent = player + 1
    score = 0
    player_count = window.count(player)
    opponent_count = window.count(opponent)
    empty_count = window.count(0)
    
    if player_count == 6 and empty_count == 0:
        score += SIX_IN_LINE  # Jugador tiene 6 en línea
    if player_count == 5 and empty_count == 1:
        score += FIVE_IN_LINE  # Jugador tiene 5 en línea con un espacio libre
    elif player_count == 4 and empty_count == 2:
        score += FOUR_IN_LINE  # Jugador tiene 4 en línea con dos espacios libres
    elif player_count == 3 and empty_count == 3:
        score += THREE_IN_LINE # Jugador tiene 3 en línea con tres espacios libres
    elif player_count == 2 and empty_count == 4:
        score += TWO_IN_LINE  # Jugador tiene 2 en línea con cuatro espacios libres
    elif player_count == 1 and empty_count == 5:
        score += ONE_IN_LINE  # Jugador tiene 1 en línea con cinco espacios libres
    
    # Penalizar al oponente con los mismos criterios
    if opponent_count == 6 and empty_count == 0:
        score -= SIX_IN_LINE  # Oponente tiene 6 en línea
    if opponent_count == 5 and empty_count == 1:
        score -= FIVE_IN_LINE  # Oponente tiene 5 en línea con un espacio libre
    elif opponent_count == 4 and empty_count == 2:
        score -= FOUR_IN_LINE  # Oponente tiene 4 en línea con dos espacios libres
    elif opponent_count == 3 and empty_count == 3:
        score -= THREE_IN_LINE  # Oponente tiene 3 en línea con tres espacios libres
    elif opponent_count == 2 and empty_count == 4:
        score -= TWO_IN_LINE  # Oponente tiene 2 en línea con cuatro espacios libres
    elif opponent_count == 1 and empty_count == 5:
        score -= ONE_IN_LINE  # Oponente tiene 1 en línea con cinco espacios libres
    
    return score

#------------------------------------------------------------------------------
#                       Funciones de movimientos
#------------------------------------------------------------------------------
def order_moves_with_half_moves(board, current_color, original_moves):
    # Obtener movimientos originales ordenados por evaluación estática
    ordered_original_moves = order_moves(original_moves, board, current_color)

    # Generar movimientos adicionales alrededor de las últimas piedras jugadas
    half_moves = generate_half_moves_around_premoves(board, current_color)

    # Unir movimientos originales y movimientos adicionales
    all_moves = ordered_original_moves + half_moves

    # Evaluar estáticamente cada movimiento y ordenarlos en función de la evaluación
    evaluated_moves = [(move, evaluate_move(board, move, current_color)) for move in all_moves]
    sorted_moves = sorted(evaluated_moves, key=lambda x: x[1], reverse=True)

    # Retornar la lista de movimientos ordenados
    return [move[0] for move in sorted_moves]

# Recoger las posiciones de las fichas colocadas en el turno anterior
def get_previous_turn_stones(board, current_color):
    previous_turn_stones = []
    for x in range(len(board)-1):
        for y in range(len(board[x])-1):
            if board[x][y] == current_color:
                previous_turn_stones.append(StonePosition(x, y))
    return previous_turn_stones

# Algoritmo de defensa Conecta6
def generate_half_moves_around_premoves(board, current_color):
    preMove = get_previous_turn_stones(board, current_color)
    half_moves = []
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]

    for position in preMove:
        for direction in directions:
            for i in range(-3, 4):  # Rango de 3 posiciones alrededor de preMove
                x = position.x + i * direction[0]
                y = position.y + i * direction[1]

                if 0 <= x < len(board) and 0 <= y < len(board[0]) and board[x][y] == 0:  # Verificar si la posición está dentro del tablero y es válida
                    half_move = (x,y)
                    half_moves.append(half_move)
    return half_moves

def order_moves(moves, board, current_color):
    # Evaluar estáticamente cada movimiento y ordenarlos en función de la evaluación
    evaluated_moves = [(move, evaluate_move(board, move, current_color)) for move in moves]
    sorted_moves = sorted(evaluated_moves, key=lambda x: x[1], reverse=True)
    return [move[0] for move in sorted_moves]

def evaluate_move(board, move, color):
    x, y = move

    # Evaluar la posición después de realizar el movimiento
    board_after_move = deepcopy(board)
    board_after_move[x][y] = color

    # Calcular la puntuación basada en alguna heurística específica
    score = evaluate_board(board_after_move, color)

    return score

