from game_engine import GameEngine
import sys

def main():
    gameEngine = GameEngine('pav')
    gameEngine.run()

if __name__ == "__main__":
    main()
