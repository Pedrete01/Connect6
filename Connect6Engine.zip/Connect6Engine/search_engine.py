from tools import *
from copy import deepcopy
import random

class SearchEngine():
    def __init__(self):
        self.m_board = None
        self.m_chess_type = None
        self.m_alphabeta_depth = None
        self.m_total_nodes = 0

    def before_search(self, board, color, alphabeta_depth):
        self.m_board = [row[:] for row in board]
        self.m_chess_type = color
        self.m_alphabeta_depth = alphabeta_depth
        self.m_total_nodes = 0

    def alpha_beta_search(self, depth, alpha, beta, ourColor, bestMove, preMove, maximizing_player = True, cont = 2):
        if(depth == 2):
            depth = 1
            
        if cont == 0:
            maximizing_player = not maximizing_player
            cont = 2
            depth = depth - 1

        # Comprobar si la profundidad ha llegado a 0 (hojas del arbol), o el juego termina
        if depth == 0 or is_win_by_premove(self.m_board, preMove):
            return evaluate_board(self.m_board, ourColor)
        
        if ourColor == 2:
            opponent = 1
        else:
            opponent = 2

        # Comprueba que jugada es
        isFirstMove = self.check_first_move()

        # Si es la primera ficha
        if  isFirstMove == 0:
            bestMove.positions[0].x = 10
            bestMove.positions[0].y = 10
            bestMove.positions[1].x = 10
            bestMove.positions[1].y = 10
            return alpha

        # Si es la primera ficha segundo jugador
        elif isFirstMove == 1:
            moves = self.find_first_move()
            bestMove.positions[0].x = moves[0]
            bestMove.positions[0].y = moves[1]
            bestMove.positions[1].x = moves[0]
            bestMove.positions[1].y = moves[1]
            make_move(self.m_board, bestMove, ourColor)
            cont = cont - 1

        if maximizing_player:
            max_eval = float('-inf')
            beta = float('-inf')
            local_best_move = StoneMove()  # Variable para almacenar la mejor jugada local

            possibleMoves = self.find_possible_moves()
            ordered_moves = order_moves_with_half_moves(self.m_board, ourColor, possibleMoves)
            
            # Utilizar una copia de bestMove antes de entrar en el bucle
            currentMove = deepcopy(bestMove)

            for move in ordered_moves:
                if isFirstMove == 1:
                    currentMove.positions[1].x = deepcopy(move[0])
                    currentMove.positions[1].y = deepcopy(move[1])
                else:
                    if cont == 2:
                        currentMove.positions[0].x = deepcopy(move[0])
                        currentMove.positions[0].y = deepcopy(move[1])
                        currentMove.positions[1].x = deepcopy(move[0])
                        currentMove.positions[1].y = deepcopy(move[1])
                    else:
                        currentMove.positions[0].x = deepcopy(preMove.positions[0].x)
                        currentMove.positions[0].y = deepcopy(preMove.positions[0].y)
                        currentMove.positions[1].x = deepcopy(move[0])
                        currentMove.positions[1].y = deepcopy(move[1])

                make_move(self.m_board, currentMove, ourColor)
                preMove.positions = deepcopy(currentMove.positions)
                eval = self.alpha_beta_search(depth, alpha, beta, ourColor, currentMove, preMove, True, cont - 1)
                unmake_move(self.m_board, currentMove)

                # Actualizar la mejor jugada local si la evaluación actual es mejor
                if eval > max_eval:
                    max_eval = eval
                    local_best_move.positions = deepcopy(currentMove.positions)
                
                if max_eval >= beta:
                    # Si la evaluación actual es mayor o igual que beta, realizar el corte alfa-beta
                    break
                
                alpha = max(alpha, eval)

            # Copiar la mejor jugada local a la estructura de datos bestMove
            bestMove.positions = deepcopy(local_best_move.positions)

            return max_eval
        else:
            min_eval = float('inf')
            alpha = float('inf')
            local_best_move = StoneMove()  # Variable para almacenar la mejor jugada local
            possibleMoves = self.find_possible_moves()
            ordered_moves = order_moves_with_half_moves(self.m_board, ourColor, possibleMoves)
            
            # Utilizar una copia de bestMove antes de entrar en el bucle
            currentMove = deepcopy(bestMove)

            for move in ordered_moves:
                if cont == 2:
                    currentMove.positions[0].x = deepcopy(move[0])
                    currentMove.positions[0].y = deepcopy(move[1])
                    currentMove.positions[1].x = deepcopy(move[0])
                    currentMove.positions[1].y = deepcopy(move[1])
                else:
                    currentMove.positions[0].x = deepcopy(preMove.positions[0].x)
                    currentMove.positions[0].y = deepcopy(preMove.positions[0].y)
                    currentMove.positions[1].x = deepcopy(move[0])
                    currentMove.positions[1].y = deepcopy(move[1])

                make_move(self.m_board, currentMove, opponent)
                preMove.positions = deepcopy(currentMove.positions)
                eval = self.alpha_beta_search(depth, alpha, beta, ourColor, currentMove, preMove, False, cont - 1)
                unmake_move(self.m_board, currentMove)

                # Actualizar la mejor jugada local si la evaluación actual es mejor
                if eval < min_eval:
                    min_eval = eval
                    local_best_move.positions = deepcopy(currentMove.positions)
                
                if min_eval <= alpha:
                    # Si la evaluación actual es menor o igual que alpha, realizar el corte alfa-beta
                    break
                
                beta = min(beta, eval)

            # Copiar la mejor jugada local a la estructura de datos bestMove
            bestMove.positions = deepcopy(local_best_move.positions)
            
            return min_eval

#------------------------------------------------------------------------------
#                       Funciones de movimientos
#------------------------------------------------------------------------------

    # Comprueba si es el primer movimiento de la partida
    def check_first_move(self):
        cont = 0
        for i in range(1, len(self.m_board) - 1):
            for j in range(1, len(self.m_board[i]) - 1):
                if self.m_board[i][j] != Defines.NOSTONE:
                    cont += 1
        return cont

    # Lista de los posibles movimiento, espacios vacios del tablero
    def find_possible_moves(self):
        moves =  []
        for i in range(1, len(self.m_board) - 1):
            for j in range(1, len(self.m_board[i]) - 1):
                if self.m_board[i][j] == Defines.NOSTONE:
                    moves.append((i,j))
        return list(moves)

    # Devuelvo la lista de movimientos posibles en un rango de 5 x 5 
    # teniendo como centro el primer movimiento

    def find_first_move(self):
        for i in range(1, len(self.m_board) - 1):
            for j in range(1, len(self.m_board[i]) - 1):
                if self.m_board[i][j] != Defines.NOSTONE:
                    return self.find_possible_moves_first(i, j)
        return (-1, -1)

    def find_possible_moves_first(self, i, j):
        moves = {(x, y) for x in range(i - 5, i + 5) for y in range(j - 5, j + 5) if 1 <= x < len(self.m_board) - 1 and 1 <= y < len(self.m_board[i]) - 1}
        num = random.randint(0, len(moves) - 1)
        return list(moves)[num]

    # Devuelvo la lista movimientos posibles en un rango de 5 x 5
    # teniendo en cuenta las ultimas piezas jugadas por el rival 
    
    def find_possible_moves_preMove(self, i, j):
        moves = {(x, y) for x in range(i - 5, i + 5) for y in range(j - 5, j + 5) if 1 <= x < len(self.m_board) - 1 and 1 <= y < len(self.m_board[i]) - 1}
        num = random.randint(0, len(moves) - 1)
        return list(moves)[num]
    
def flush_output():
    import sys
    sys.stdout.flush()